  <link rel="stylesheet" href="{{CSS}}alertify/themes/alertify.core.css" >
  <link rel="stylesheet" href="{{CSS}}alertify/themes/alertify.default.css" id="toggleCSS" >

 <script src="{{JS}}alertify.js"></script>