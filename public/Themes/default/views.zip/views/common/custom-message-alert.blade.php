
<script>

	function showMessage(slug) {
	swal("info!",slug, "info");
		 
	}
</script>