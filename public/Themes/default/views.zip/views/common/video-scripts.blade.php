 <link href="{{CSS}}video-js.css" rel="stylesheet">
 <script src="{{JS}}video.js"></script>