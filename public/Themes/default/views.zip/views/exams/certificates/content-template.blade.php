<?php 
echo isset($content) ?  $content :'';

    