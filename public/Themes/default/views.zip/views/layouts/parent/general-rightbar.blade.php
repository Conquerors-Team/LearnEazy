
				<div class="panel-heading">
					<h2>Today Task</h2>
				</div>
				<div class="panel-body">
					
					<br> Content will come in this place
				

				</div>

				<div class="panel-heading countdount-heading">
					<h2>Latest Messages</h2>
				</div>
				<div class="panel-body">
					
					<ul class="list-replay list-sidebar">
						<li>
							<a href="">
								<img src="/images/photo-64-2.jpg" alt="">
								<h4>Prameshwar Kumar <span class="time"><i class="mdi mdi-clock"></i> 25 min ago</span></h4>
								<p>The standard chunk of Lorem ...</p>
								<i class="mdi arrow-link mdi-chevron-right"></i>
							</a>
						</li>
						<li>
							<a href="">
								<img src="/images/photo-64-2.jpg" alt="">
								<h4>Prameshwar Kumar <span class="time"><i class="mdi mdi-clock"></i> 25 min ago</span></h4>
								<p>The standard chunk of Lorem ...</p>
								<i class="mdi arrow-link mdi-chevron-right"></i>
							</a>
						</li>
						<li>
							<a href="">
								<img src="/images/photo-64-2.jpg" alt="">
								<h4>Prameshwar Kumar <span class="time"><i class="mdi mdi-clock"></i> 25 min ago</span></h4>
								<p>The standard chunk of Lorem ...</p>
								<i class="mdi arrow-link mdi-chevron-right"></i>
							</a>
						</li>
						<li>
							<a href="">
								<img src="/images/photo-64-2.jpg" alt="">
								<h4>Prameshwar Kumar <span class="time"><i class="mdi mdi-clock"></i> 25 min ago</span></h4>
								<p>The standard chunk of Lorem ...</p>
								<i class="mdi arrow-link mdi-chevron-right"></i>
							</a>
						</li>
						<li>
							<a href="">
								<img src="/images/photo-64-2.jpg" alt="">
								<h4>Prameshwar Kumar <span class="time"><i class="mdi mdi-clock"></i> 25 min ago</span></h4>
								<p>The standard chunk of Lorem ...</p>
								<i class="mdi arrow-link mdi-chevron-right"></i>
							</a>
						</li>
						<li>
							<a href="">
								<img src="/images/photo-64-2.jpg" alt="">
								<h4>Prameshwar Kumar <span class="time"><i class="mdi mdi-clock"></i> 25 min ago</span></h4>
								<p>The standard chunk of Lorem ...</p>
								<i class="mdi arrow-link mdi-chevron-right"></i>
							</a>
						</li>
						<li>
							<a href="">
								<img src="/images/photo-64-2.jpg" alt="">
								<h4>Prameshwar Kumar <span class="time"><i class="mdi mdi-clock"></i> 25 min ago</span></h4>
								<p>The standard chunk of Lorem ...</p>
								<i class="mdi arrow-link mdi-chevron-right"></i>
							</a>
						</li>
					</ul>
				
				</div>