<?php 
echo isset($header) ?  $header :'';
echo isset($body) ?  $body :'';
echo isset($footer) ?  $footer :'';
    