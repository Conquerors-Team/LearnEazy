<div class="row">
    <div class="col-lg-12">
	<p style="font-size:16px;margin:10px 0;font-style: italic;">DISCLAIMER:</p>
	<p style="font-size:12px;margin:10px 0; font-style: italic;">This e-mail is only intended for the person(s) to whom it is addressed and may contain confidential information. Unless stated to the contrary, any opinions or comments are personal to the writer and do not represent the official view of the company. If you have received this e-mail in error, please notify us immediately by reply e-mail and then delete this message from your system. Please do not copy it or use it for any purposes, or disclose its contents to any other person. Thank you for your cooperation.</p>
 
	</div>
   </div>