<div class="row">
    <div class="col-md-12">
         
        <div class="textarea-hint">
            <fieldset class="form-group">
                <textarea class="form-control" name="{{$question->id}}[]" placeholder="Enter Your answer" rows="3"></textarea>
            </fieldset>
        </div>

    </div>
    
</div>